
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Driver obj = new Driver();
		obj.run();

	  }

	  public void run() {

		String csvFile = "C:/Users/Rodrigo/workspace/ReadCSVFile/src/airports.txt";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";

		try {

			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
				PrintStream out = new PrintStream(new FileOutputStream("C:/Users/Rodrigo/workspace/ReadCSVFile/src/code.txt"));
				System.setOut(out);
				
			        // use comma as separator
				String[] lines = line.split(cvsSplitBy);

				System.out.println("airportValues.put(AIRPORT_NAME, " + lines[1] + ");");
				System.out.println("airportValues.put(AIRPORT_CITY, " + lines[2] + ");");
				System.out.println("airportValues.put(AIRPORT_COUNTRY, " + lines[3] + ");");
				System.out.println("airportValues.put(AIRPORT_IATA_FAA, " + lines[4] + ");");
				System.out.println("airportValues.put(AIRPORT_ICAO, " + lines[5] + ");");
				System.out.println("airportValues.put(AIRPORT_LATITUDE, " + lines[6] + ");");
				System.out.println("airportValues.put(AIRPORT_LONGITUDE, " + lines[7] + ");");
				System.out.println("airportValues.put(AIRPORT_ALTITUDE, " + lines[8] + ");");
				System.out.println("airportValues.put(AIRPORT_TIMEZONE, " + lines[9] + ");");
				System.out.println("airportValues.put(AIRPORT_DST, " + lines[10] + ");");
				System.out.println("airportValues.put(AIRPORT_DTZ, " + lines[11] + ");");
				System.out.println(" ");
				System.out.println("db.insert(" + "airports_table" + ", null, airportValues);");
				System.out.println(" ");
				

			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		System.out.println("Done");
	  }

}
